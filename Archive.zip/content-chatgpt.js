console.log('PDF to ChatGPT: Content script loaded');

setTimeout(async () => {
  await checkForPendingPDF();
}, 2000);

async function checkForPendingPDF() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getPDFData' });

    if (response.success && response.pdfData && response.platform === 'chatgpt') {
      console.log('PDF to ChatGPT: Found pending PDF, preparing to upload');
      await uploadPDFToChatGPT(response.pdfData, response.fileName, response.prompt);
    }
  } catch (error) {
    console.error('PDF to ChatGPT: Error checking for pending PDF:', error);
  }
}

async function uploadPDFToChatGPT(base64Data, fileName, prompt) {
  try {
    const blob = base64ToBlob(base64Data, 'application/pdf');
    const file = new File([blob], fileName, { type: 'application/pdf' });

    const fileInput = await findFileInput();

    if (fileInput) {
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      fileInput.files = dataTransfer.files;

      const changeEvent = new Event('change', { bubbles: true });
      fileInput.dispatchEvent(changeEvent);

      console.log('PDF to ChatGPT: File uploaded via input');

      await new Promise(resolve => setTimeout(resolve, 5000));

      const textarea = await waitForElement('div#prompt-textarea[contenteditable="true"], #prompt-textarea', 10000);

      if (!textarea) {
        console.error('PDF to ChatGPT: Could not find ChatGPT input field after upload');
        return;
      }

      console.log('PDF to ChatGPT: Found input field:', textarea);

      if (prompt) {
        await insertPromptAndSubmit(textarea, prompt);
      }
    } else {
      console.error('PDF to ChatGPT: Could not find file input');
    }
  } catch (error) {
    console.error('PDF to ChatGPT: Error uploading PDF:', error);
  }
}

async function findFileInput() {
  const selectors = [
    'input[type="file"]',
    'input[accept*="pdf"]',
    'input[accept*="application/pdf"]'
  ];

  for (const selector of selectors) {
    const input = document.querySelector(selector);
    if (input) {
      return input;
    }
  }

  const attachButtons = document.querySelectorAll('button[aria-label*="Attach"], button[aria-label*="附加"], button svg');
  for (const button of attachButtons) {
    const btn = button.tagName === 'BUTTON' ? button : button.closest('button');
    if (btn) {
      btn.click();
      await new Promise(resolve => setTimeout(resolve, 500));

      const input = document.querySelector('input[type="file"]');
      if (input) {
        return input;
      }
    }
  }

  return null;
}

async function insertPromptAndSubmit(element, prompt) {
  element.focus();
  await new Promise(resolve => setTimeout(resolve, 300));

  console.log('PDF to ChatGPT: Element type:', element.tagName, 'contenteditable:', element.getAttribute('contenteditable'));

  if (element.getAttribute('contenteditable') === 'true') {
    element.innerHTML = '';

    let p = element.querySelector('p');
    if (!p) {
      p = document.createElement('p');
      element.appendChild(p);
    }

    p.removeAttribute('data-placeholder');
    p.classList.remove('placeholder');
    p.textContent = prompt;

    element.textContent = prompt;
    element.innerText = prompt;

    console.log('PDF to ChatGPT: Set content to contenteditable div');
  } else {
    element.value = prompt;

    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype,
      'value'
    )?.set;

    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(element, prompt);
    }
  }

  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
  element.dispatchEvent(new InputEvent('input', {
    bubbles: true,
    cancelable: true,
    inputType: 'insertText',
    data: prompt
  }));

  console.log('PDF to ChatGPT: Prompt inserted, content:', element.textContent?.substring(0, 50));

  await new Promise(resolve => setTimeout(resolve, 2000));

  const submitButton = await findSubmitButton();
  if (submitButton) {
    console.log('PDF to ChatGPT: Found submit button, clicking');

    if (!submitButton.disabled) {
      submitButton.click();
      console.log('PDF to ChatGPT: Submit button clicked');
    } else {
      console.log('PDF to ChatGPT: Submit button is disabled, trying Enter key');
      const enterEvent = new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        bubbles: true,
        cancelable: false
      });
      element.dispatchEvent(enterEvent);
    }
  } else {
    console.log('PDF to ChatGPT: Submit button not found, using Enter key');
    const enterEvent = new KeyboardEvent('keydown', {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      bubbles: true,
      cancelable: false
    });
    element.dispatchEvent(enterEvent);
  }
}

async function findSubmitButton() {
  for (let i = 0; i < 10; i++) {
    const selectors = [
      'button[data-testid="send-button"]',
      'button[data-testid="fruitjuice-send-button"]',
      'button[aria-label*="Send"]',
      'button[aria-label*="送出"]',
      'button[type="submit"]'
    ];

    for (const selector of selectors) {
      const button = document.querySelector(selector);
      if (button && !button.disabled) {
        console.log(`PDF to ChatGPT: Found submit button with selector: ${selector}`);
        return button;
      }
    }

    const buttons = document.querySelectorAll('button');
    for (const button of buttons) {
      const ariaLabel = button.getAttribute('aria-label')?.toLowerCase() || '';
      const buttonText = button.textContent?.toLowerCase() || '';

      if ((ariaLabel.includes('send') || buttonText.includes('send')) && !button.disabled) {
        console.log('PDF to ChatGPT: Found submit button by text/aria-label');
        return button;
      }
    }

    if (i < 9) {
      console.log(`PDF to ChatGPT: Waiting for submit button... attempt ${i + 1}/10`);
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }

  const form = document.querySelector('form[data-type="unified-composer"]');
  if (form) {
    console.log('PDF to ChatGPT: Found composer form');

    const trailingArea = form.querySelector('[class*="grid-area:trailing"], .\\[grid-area\\:trailing\\]');
    if (trailingArea) {
      console.log('PDF to ChatGPT: Found trailing area');
      const buttons = trailingArea.querySelectorAll('button');

      for (const button of buttons) {
        const classes = button.className;
        if ((classes.includes('rounded-full') || classes.includes('composer-secondary-button'))
            && !button.disabled
            && !button.getAttribute('aria-label')?.includes('Dictate')
            && !button.getAttribute('aria-label')?.includes('voice')) {
          console.log('PDF to ChatGPT: Found potential submit button in trailing area');
          return button;
        }
      }
    }

    const roundButtons = form.querySelectorAll('button.rounded-full, button[class*="rounded-full"]');
    for (const button of roundButtons) {
      const ariaLabel = button.getAttribute('aria-label')?.toLowerCase() || '';
      if (!ariaLabel.includes('voice') &&
          !ariaLabel.includes('dictate') &&
          !ariaLabel.includes('remove') &&
          !ariaLabel.includes('delete') &&
          !ariaLabel.includes('移除') &&
          !ariaLabel.includes('刪除') &&
          !button.disabled) {
        console.log('PDF to ChatGPT: Found round button (likely submit):', ariaLabel);
        return button;
      }
    }
  }

  await new Promise(resolve => setTimeout(resolve, 500));

  const allButtons = document.querySelectorAll('button');
  let rightmostButton = null;
  let maxRight = 0;

  for (const button of allButtons) {
    if (button.disabled) continue;

    const ariaLabel = button.getAttribute('aria-label')?.toLowerCase() || '';
    if (ariaLabel.includes('remove') ||
        ariaLabel.includes('delete') ||
        ariaLabel.includes('voice') ||
        ariaLabel.includes('dictate') ||
        ariaLabel.includes('plus') ||
        ariaLabel.includes('add')) {
      continue;
    }

    const rect = button.getBoundingClientRect();
    if (rect.right > maxRight && rect.bottom > window.innerHeight - 200) {
      maxRight = rect.right;
      rightmostButton = button;
    }
  }

  if (rightmostButton) {
    console.log('PDF to ChatGPT: Found rightmost button (likely submit):', rightmostButton.getAttribute('aria-label'));
    return rightmostButton;
  }

  console.log('PDF to ChatGPT: No submit button found');
  return null;
}

function base64ToBlob(base64, mimeType) {
  const byteCharacters = atob(base64);
  const byteNumbers = new Array(byteCharacters.length);

  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }

  const byteArray = new Uint8Array(byteNumbers);
  return new Blob([byteArray], { type: mimeType });
}

function waitForElement(selector, timeout = 5000) {
  return new Promise((resolve) => {
    const element = document.querySelector(selector);
    if (element) {
      resolve(element);
      return;
    }

    const observer = new MutationObserver((mutations, obs) => {
      const element = document.querySelector(selector);
      if (element) {
        obs.disconnect();
        resolve(element);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    setTimeout(() => {
      observer.disconnect();
      resolve(null);
    }, timeout);
  });
}
